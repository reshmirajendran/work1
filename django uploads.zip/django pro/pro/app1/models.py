from django.db import models

# Create your models here.
class book(models.Model):
    title=models.CharField(max_length=20)
    auther=models.CharField(max_length=20)
    pdf=models.FileField(upload_to='book/cover')
    cover=models.ImageField(upload_to='Book/cover',null=True,blank=True)