from django.shortcuts import render
from app1.models import book
from app1.forms import bookform
def home(request):
    return render(request,'home.html')

def add(request):
    form=bookform()
    if(request.method=='POST'):
        form=bookform(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return home(request)
    return render (request,'add.html',{"form":form})
def view(request):
    s=book.objects.all()
    return render(request,'view.html',{"s":s})